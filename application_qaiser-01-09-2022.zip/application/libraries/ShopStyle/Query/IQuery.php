<?php

namespace ShopStyle\Query;


interface IQuery
{
    public function get($url);
}