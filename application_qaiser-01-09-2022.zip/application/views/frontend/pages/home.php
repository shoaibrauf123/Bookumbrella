<style>
    @font-face {
        font-family: 'fonts/Roboto-Bold';
        src: url('fonts/Roboto-Bold.eot'); /* IE9 Compat Modes */
        src: url('fonts/Roboto-Bold.eot?#iefix') format('embedded-opentype'), /* IE6-IE8 */ url('fonts/Roboto-Bold.woff2') format('woff2'), /* Super Modern Browsers */ url('fonts/Roboto-Bold.woff') format('woff'), /* Pretty Modern Browsers */ url('fonts/Roboto-Bold.ttf') format('truetype'), /* Safari, Android, iOS */ url('fonts/Roboto-Bold.svg#svgFontName') format('svg'); /* Legacy iOS */
    }

    i.fa-solid.fa-circle-chevron-left{
    font-family: "Font Awesome 6 Free";
    font-weight: 900;
    position: absolute;
    top: 35%;
    display: flex;
    justify-content: center;
    border-bottom-right-radius: 4px;
    border-top-right-radius: 4px;
    align-items: center;
    left: 0px;
    background: #bb9870;
    height: 80px;
    width: 41px;
}
i.fa-solid.fa-circle-chevron-right{
    font-family: "Font Awesome 6 Free";
    font-weight: 900;
    position: absolute;
    top: 35%;
    display: flex;
    justify-content: center;
    border-bottom-left-radius: 4px;
    border-top-left-radius: 4px;
    align-items: center;
    right: 0px;
    background: #bb9870;
    height: 80px;
    width: 41px;
}


</style>

 <link href='https://fonts.googleapis.com/css?family=Roboto' rel='stylesheet' type='text/css'>

<div class="col-xs-12 no-padding">
    <!-- <div class="">
        <div class="row no-padding">
            <div class="col-sm-12 no-padding"> -->
                <div class="container no-padding">
                    <div class=" myslider no-padding">
                        <div id="myCarousel" class="carousel slide hght_slider" data-ride="carousel">
                            <div class="carousel-inner hght_slider" role="listbox">
                                <div class="item active">
                                    <img src="assets/frontend/img/banner.jpg" class="slider_img" align="right" onclick="window.location = '<?php echo base_url('products') ?>'">
                                </div>
                                <div class="item">
                                    <img src="assets/frontend/img/fantastic_flying_books.jpg" class="slider_img" align="right" onclick="window.location = '<?php echo base_url('products') ?>'">
                                </div>
                                <div class="item">
                                    <img src="assets/frontend/img/travel-books-horizontal-shelf-several-composition-40901103.jpg" class="slider_img" align="right" onclick="window.location = '<?php echo base_url('products') ?>'">
                                </div>
                            </div>
                            <a data-slide="prev" href="#myCarousel" class="left carousel-control">
                                <!-- <span class="icon-prev"><img src="assets/frontend/img/arrow_left.png" alt=""/></span> -->
                                <i class="fa-solid fa-circle-chevron-left"></i>
                            </a>
                            <a data-slide="next" href="#myCarousel" class="right carousel-control">
                                <!-- <span class="icon-next"><img src="assets/frontend/img/arrow_right.png" alt=""/></span> -->
                                <i class="fa-solid fa-circle-chevron-right"></i>
                            </a>
                            
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-3 col-xs-12" style="display:none;">
                <?php $referUserLink = $this->session->userdata('logged_in') ? base_url('refer_friend'):base_url('login'); ?>
                <img src="assets/frontend/img/s_side.jpg" class="img-responsive imgslidlft"  alt="">
            </div>
        <!-- </div>
    </div>
</div> -->

<div class="clear35"></div>

<div class="col-xs-12 no-padding">
    <div class="">
        <div class="row no-padding">
            <div class="hdg_bg"><span title="Best Sellers"><?php echo getlanguage('popular_brands');?></span><span class="pull-right"><a href="<?php echo base_url('products');?>" class=" btn btn-default" title="view all"><?php echo getlanguage('view_all');?></a></span></div>
            
        </div>
    </div>
</div>

<div class="clear20"></div>

<div class="col-xs-12 no-padding">
<div class="">

    <div class="row no-padding home-prod-data-cont">
        <?php if ($most_sold) { $i = 0; ?>
            <?php foreach ($most_sold as $product) { $i++; ?>
                <a
                        href="<?php echo base_url('product/detail') . "/" . encode_url($product['product_id']); ?>">
                    <div class="product-col list clearfix col-sm-2 product_col_sepration">
                        <div class="image col-sm-12 image_product"><img class="img_height"
                                                                        alt="product"
                                                                        src="<?php echo base_url(''); ?><?php echo $product['image'] ?>">
                        </div>
                        <div class="clearfix"></div>
                        <div class="caption col-sm-12">
                            <h4><?php echo $product['title']; ?></h4>
                            <p class="author"><?php echo $product['author']; ?>   </p>



                            <div class="price no-padding" style="margin:0; padding:0px;">
                                <p class="price-tax" style=""><span
                                            class="price">$<?php echo $product['buy_price'] ? $product['buy_price'] : $product['buy_price']; ?></span>
                                </p>
                            </div>
                            <div class="price no-padding" style="margin:0; padding:0px;">

                                <a class="btn btn-cart btn-block btncatg" type="button"  href="<?php echo base_url('product/detail/'.encode_url($product['product_id']));?>" title="Product Details">
                                    Details

                                </a>
                            </div>

                        </div>
                    </div>
                </a>
            <?php }
        } else {
            echo '<div class="alert alert-danger">Sorry ! No product found</div>';
        }
        ?>
    </div>

    </div>



    <?php /*?><div class="">
        <div class="row no-padding">
            <?php if($stores_data) { ?>
                <?php for($i=0; $i< count($stores_data); $i++){ ?>
                    <div class="view_box">

                        <?php if($stores_data[$i]['image_url'] !=''){
                            $img = base_url('uploads/img_gallery/store_images').'/'.$stores_data[$i]['image_url'];
                        } else {
                            $img = base_url('uploads/img_gallery/store_images/default-store-350x350.jpg');
                        }?>

                        <div class="pdg_15 align_img"><img alt="Store" src="<?php echo $img; ?>"></div>
                        <div class="view_box_wt">
                            <h2 class="limit-product-title-to-single-line"><?php echo $stores_data[$i]['name']; ?></h2>
                            <div class="limit-mini-thumb-desc">
                                <?php echo $stores_data[$i]['short_description']; ?>
                            </div>
                            <div class="clear10"></div>
                            <a href="<?php echo base_url('products')."?user_id=".$stores_data[$i]['user_id']; ?>" class="btn btn-success" >View Books</a>
                        </div>
                    </div>
                <?php } ?>
            <?php } ?>
        </div>
      

    </div><?php */?>
</div>




<div class="clear20"></div>



<div class="clear10"></div>

<div class="col-xs-12 no-padding">
    <div class="">
        <div class="row no-padding">
            <div class="hdg_bg"><span title="Most Viewed"><?php echo getlanguage('most_viewed');?></span><span class="pull-right"><a href="<?php echo base_url('products');?>" class=" btn btn-default" title="view all"><?php echo getlanguage('view_all');?></a></span></div>
            
        </div>
    </div>
</div>

<div class="clear20"></div>

<div class="col-xs-12 no-padding">
    
    <div class="">
        
        <div class="row no-padding home-prod-data-cont">
            <?php if ($products_data) { $i = 0; ?>
                    <?php foreach ($products_data as $product) { $i++; ?>
                        <a 
                                   href="<?php echo base_url('product/detail') . "/" . encode_url($product['product_id']); ?>">
                            <div class="product-col list clearfix col-sm-3 product_col_sepration">
                                <div class="image col-sm-12 image_product"><img class="img_height"
                                                                                        alt="product"
                                                                                        src="<?php echo base_url(''); ?><?php echo $product['image'] ?>">
                                </div>
                                <div class="clearfix"></div>
                                <div class="caption col-sm-12">
                                    <h4><?php echo $product['title']; ?></h4>
                                <p class="author"><?php echo $product['author']; ?>   </p>
             
         

                                    <div class="price no-padding" style="margin:0; padding:0px;">
                                        <p class="price-tax" style=" "><span
                                                class="price">$<?php echo $product['buy_price'] ? $product['buy_price'] : $product['buy_price']; ?></span>
                                        </p>
                                    </div>
                            <div class="price no-padding" style="margin:0; padding:0px;">
                            
                            <a class="btn btn-cart btn-block btncatg" type="button"  href="<?php echo base_url('product/detail/'.encode_url($product['product_id']));?>" title="Product Details">
                                 Details
                                 
                             </a>
                             </div>
                             
                                </div>
                            </div>
                        </a>
                    <?php }
                } else {
                    echo '<div class="alert alert-danger">Sorry ! No product found</div>';
                }
            ?>
        </div>

    </div>
</div>

<div class="clear10"></div>

<div class="col-xs-12">
    <div class="">
        <div class="row no-padding">

            <div class="col-sm-4 col-xs-12 pdg_leftnone">
                <div class="gurnate_box" >
                    <h2 title="Safisfaction 100% guranteed"><?php echo getlanguage('satisfaction');?></h2>

                    <h3>100% <?php echo getlanguage('guranteed');?></h3>

                    <div class="clear20"></div>
                    <?php 
                   $data = get('static_page',array('slug'=>'satisfaction_guranteed'));
                   if($data) {
                   $string = $data[0]['description'];
                   if(strlen($string) > 170)
                   echo $stringCut = substr($string, 0, 170);
                   ?>
                    <a href="<?php echo base_url('pages').'/'.$data[0]['slug'];?>">READ MORE</a>
                   <?php } ?>
                </div>
            </div>


            <div class="col-sm-4 col-xs-12">
                <div class="gurnate_box">
                    <div class="pull-left"><img src="assets/frontend/img/shipping.png" alt=""></div>

                    <div class="pull-left" style="margin-left:20px;">
                        <h2 title="Free shipping"><?php echo getlanguage('free');?> </h2>
                        <h3><?php echo getlanguage('shipping');?></h3></div>
                    <div class="clear20"></div>
                   <?php 
                   $data = get('static_page',array('slug'=>'satisfaction_guranteed'));
                   if($data) {
                   $string = $data[0]['description'];
                   if(strlen($string) > 165)
                   echo $stringCut = substr($string, 0, 165);
                   ?>
                    <a href="<?php echo base_url('pages').'/'.$data[0]['slug'];?>">READ MORE</a>
                   <?php } ?>
                </div>
            </div>


            <div class="col-sm-4 col-xs-12 pdg_rightnone">
                <div class="gurnate_box">
                    <div class="pull-left"><img src="assets/frontend/img/returen.png" alt=""></div>
                    <div class="pull-left" style="margin-left:20px;">
                        <h2 title="14 day Easy return">14 <?php echo getlanguage('day');?></h2>
                        <h3><?php echo getlanguage('easy_return');?></h3></div>
                    <div class="clear20"></div>
                   <?php 
                   $data = get('static_page',array('slug'=>'satisfaction_guranteed'));
                   if($data) {
                   $string = $data[0]['description'];
                   if(strlen($string) > 170)
                   echo $stringCut = substr($string, 0, 170);
                   ?>
                    <a href="<?php echo base_url('pages').'/'.$data[0]['slug'];?>">READ MORE</a>
                   <?php } ?>
                </div>
            </div>


        </div>
    </div>
</div>


<div class="clear20"></div>
<?php /*?><div class="col-xs-12 no-padding">
    <div class="container">
        <div class="row no-padding">

            <div class="info_box mrg_left19"><img src="assets/frontend/img/help.png" alt=""> <span title="FAQ"><?php echo getlanguage('frequently_asked_questions');?> </span></div>
            <div class="info_box"><img src="assets/frontend/img/info.png" alt=""> <span title="About us"><?php echo getlanguage('about_us');?></span></div>
            <div class="info_box"><img src="assets/frontend/img/email.png" alt=""> <span title="One-to-one contact"><?php echo getlanguage('One-to-one_contact_center');?></span></div>
            <div class="info_box"><img src="assets/frontend/img/mble_icon.png" alt=""> <span title="About us"><?php echo getlanguage('about_us');?></span></div>
            <div class="info_box"><img src="assets/frontend/img/other.png" alt=""> <span title="About us"><?php echo getlanguage('about_us');?></span></div>


        </div>
    </div>
</div><?php */?>

<div class="clear10"></div>