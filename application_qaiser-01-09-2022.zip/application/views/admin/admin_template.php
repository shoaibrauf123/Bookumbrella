
<?php $this->load->view('admin/includes/header');	?>

<?php $this->load->view('admin/includes/sidebar'); ?>

<?php $this->load->view($view_path);	?>

<?php $this->load->view('admin/includes/footer');	?>
