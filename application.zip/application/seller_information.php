<div class="col-xs-12">
    <div class="container">
    <div class="row no-padding  col-lg-offset-3">
      <h2>Seller Information</h2>
      <div class="clear30"></div>
       <div class="col-md-8 col-xs-12">


           <label>Store Name: </label>  &nbsp;&nbsp;<?php echo $store['name'];?>
           <div class="clear20"></div><label>Address: </label>&nbsp;&nbsp;<?php echo $store['address'];?>
           <div class="clear20"></div>
           <div class="clear20"></div><label>Date Created: </label>&nbsp;&nbsp;<?php echo $store['date_created'];?>
           <div class="clear20"></div>

                </div>
        
    </div> </div>
</div>