<?php $this->load->view('frontend/includes/header');  ?>

<?php  $this->load->view($main_content); ?>

<?php $this->load->view('frontend/includes/footer'); ?>