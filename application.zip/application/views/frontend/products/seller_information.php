<style>
.clear20
{
    
    margin-top:10px;
}
.btn-class{
    float:right;
}

</style>

<form action="<?php echo base_url('frontend/users/seller_information'); ?>" method="POST">
    <div class="col-xs-12">
    <div class="container">
    <div class="row no-padding  col-lg-offset-3">
      <h2>Seller Information</h2>
      <div class="clear30"></div>
       <div class="col-md-8 col-xs-12">

       
        <div class="clear20">
            <label class="seller_information">
                Store Name: 
            </label>
            <input type="text" name="name" value="<?php echo $store['name'];?>" />  
        </div>
        <div class="clear20">
            <label class="seller_information">
                Store Address: 
            </label>
            <input type="text" name="address" value="<?php echo $store['address'];?>" />  
        </div>
               <div class="clear20">
            <label class="seller_information">
                Country: 
            </label>
            <input type="text" name="country" value="<?php echo $user['country'];?>" />  
        </div>
        <?php 
           if( $user['country']=="USA"){ ?>
               <div class="clear20">
            <label class="seller_information">
                Tax ID:
            </label>
            <input type="text" name="tax_id" value="<?php echo $user['tax_id'];?>" />  
        </div>
        <div class="clear20">
            <label class="seller_information">
                Tax Type:
            </label>
            <input type="text" name="tax_type" value="<?php echo $user['tax_type'];?>" />  
        </div>
        <?php
        }
        ?>
        <div class="clear20">
            <label class="seller_information">
            E-mail:
            </label>
            <input type="text" name="email" value="<?php echo $user['email'];?>" />  
        </div>
    </div>
        
    </div><input type="submit" class="btn btn-info btn-class"></div>
</div>
</form>
<script>

</script>