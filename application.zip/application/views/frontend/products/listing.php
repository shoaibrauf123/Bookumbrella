<style>
    a.btn.btn-cart.pull-right {
    background: #bb9870;
    color: #fff;
    border-radius: 0px;
}
 a.btn.btn-cart.pull-right:hover {
       background: #323232;
}
</style>
<div class="col-xs-12">
    <div class="container product-listing-cont">
        <div class="row no-padding product_responsive">
            <?php if ($this->input->get('cat')) {
                getCategoriesNavigation(($this->input->get('cat') / 999));
            } ?>

            <div class="col-sm-12 col-xs-12">
                <form acrtion="<?php echo base_url('products'); ?>" method="get" id="frm_filter">
                    <input type="hidden" id="listing" name="listing" value="yes"/>
                    <input type="hidden" id="condition" name="condition"
                           value="<?php echo ($this->input->get('condition')) ? $this->input->get('condition') : ''; ?>"/>
                    <input type="hidden" name="cat" id="cat_id"
                           value="<?php echo ($this->input->get('cat')) ? $this->input->get('cat') : ''; ?>"/>
                    <input type="hidden" name="type" id="type"
                           value="<?php echo ($this->input->get('type')) ? $this->input->get('type') : ''; ?>"/>

                    <div>
                        <div class="product-filter">

                            <div class="product-compare col-xs-3"><a id="compare-total" href="">Product Listing
                                    (<?php echo $total_products; ?>)</a></div>
                            <div class="col-xs-12 col-lg-9 pull-right no-padding product_mobile">

                                <div class="limit" title="Show"><?php echo getlanguage('show'); ?>:
                                    <select onchange="$('#frm_filter').submit();" name="count">
                                        <option selected="selected" value="15" selected="selected">15</option>
                                        <option
                                            value="25" <?php if ($this->input->get('count') == '25') echo 'selected="selected"'; ?>>
                                            25
                                        </option>
                                        <option
                                            value="50" <?php if ($this->input->get('count') == '50') echo 'selected="selected"'; ?>>
                                            50
                                        </option>
                                        <option
                                            value="75" <?php if ($this->input->get('count') == '75') echo 'selected="selected"'; ?>>
                                            75
                                        </option>
                                        <option
                                            value="100"<?php if ($this->input->get('count') == '100') echo 'selected="selected"'; ?>>
                                            100
                                        </option>
                                    </select>
                                </div>
                                <div class="sort pull-right margin-left-10"
                                     title="Sort By">Sort By:
                                    <select onchange="$('#frm_filter').submit();" name="sort_by">
                                        <option selected="selected" value="">Default</option>
                                        <option
                                            value="name" <?php if ($this->input->get('sort_by') == 'name') echo 'selected="selected"'; ?>>
                                            brand alphabetic (A - Z)
                                        </option>
                                        <option
                                            value="price_low" <?php if ($this->input->get('sort_by') == 'price_low') echo 'selected="selected"'; ?>>
                                            Price (Low &gt; High)
                                        </option>
                                        <option
                                            value="price_high" <?php if ($this->input->get('sort_by') == 'price_high') echo 'selected="selected"'; ?>>
                                            Price (High &gt; Low)
                                        </option>
                                        <option
                                            value="most_viewed" <?php if ($this->input->get('sort_by') == 'most_viewed') echo 'selected="selected"'; ?>>
                                            Most Viewed
                                        </option>

                                    </select>
                                </div>

                                <div class="input-group">
                                    <input type="text" name="title" class="form-control product-name-filter-input"
                                           placeholder="Search by title/isbn10/isbn13..."
                                           value="<?php echo ($this->input->get('title')) ? $this->input->get('title') : ''; ?>">
                        <span class="input-group-btn btn_search" style="border-top-right-radius:5px; border-bottom-right-radius:5px; ">
                        <button class="btn btn-info btn-sm btn-mini-custom" style="border-top-right-radius:5px; border-bottom-right-radius:5px; " type="submit">
                            <i class="glyphicon glyphicon-search"></i>
                        </button>
                    </span>
                                </div>


                            </div>
                        </div>
                        
                </form>
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 no-padding">
                    <div class="prod-data-cont">
                        <?php
						
						if($isbn_products){
							$product = $isbn_products;
							//print_r($product);exit;
							?>
							
							 <a target="_blank"
                                   href="<?php echo base_url('product/detail') . "/" . encode_url($product['product_id']); ?>">
                            <div class="product-col list clearfix col-sm-3 product_col_sepration">
                                <div class="image col-sm-12 image_product">
                                <img class="img-responsive" alt="product" src="<?php echo base_url(''); ?><?php echo $product['image'] ?>">
                                
                                
                                </div>
                                <div class="clearfix"></div>
                                <div class="caption col-sm-12">
                                    <h4><?php echo $product['title']; ?></h4>

                                    <div class="price no-padding" style="margin:0; padding:0px;">
                                    
                                        <p class="price-tax" style="margin:0;"><span
                                                class="price">$<?php echo $product['sale_price'] ? $product['sale_price'] : $product['price']; ?></span>
                                        </p>
                                    </div>
                            <div class="price no-padding" style="margin:0; padding:0px;">
                            <a class="btn btn-cart" type="button" href="<?php echo base_url("product/detail");?>/<?php echo encode_url($product['product_id'])?>" title="View Detail">
                                 View Detail1
                                 
                             </a>
                             </div>
                             
                                </div>
                            </div>
                        </a>
							
							<?php
							
							}else{
						
						
                        if ($allProducts) {  ?>
                            <?php foreach ($allProducts as $product) { 
							
							$min_new_price = $this->product_model->min_product_price("seller_products",array("New"),array('product_id'=>$product['product_id'],'pause_listing'=>'no'));
							//echo '<pre>';print_r();exit;
							$min_used_price = $this->product_model->min_product_price("seller_products",array("Like New","Very Good","Good","Acceptable"),array('product_id'=>$product['product_id'],'pause_listing'=>'no'));
							
							
							
							$total_sellers_for_new = $this->product_model->total_sellers_for_condition("seller_products",array("New"),array('product_id'=>$product['product_id'],'pause_listing'=>'no'));
							//echo '<pre>';print_r();exit;
							$total_sellers_for_used = $this->product_model->total_sellers_for_condition("seller_products",array("Like New","Very Good","Good","Acceptable"),array('product_id'=>$product['product_id'],'pause_listing'=>'no'));
							
							
							
							
							
							
							//echo '<pre>';print_r($product);exit;
							 ?>
                                <div class="product-col list clearfix col-sm-12 no-padding" style="border-bottom:1px dotted #bb9870;">
          <div class="image col-sm-1">
            <a href="<?php echo base_url('product/detail') . "/" . encode_url($product['product_id']); ?>">
            <img class="" style="width:94px; height:140px;" alt="product" src="<?php echo base_url().$product['image'];?>"> </div>
            </a>
          <div class="col-xs-12 col-sm-7">
			<div>
            <h4 style="margin-bottom:0px; margin-top:0px;"><?php echo $product['title']?></h4>
            <strong style="color:gray"> Author:</strong><span style="color: rgb(187, 152, 112) !important;"><?php echo $product['author']?></span></span> <br>
            <strong> ISBN-10:</strong><span><?php echo $product['isbn']?></span></span> <br>
                <strong> ISBN-13:</strong><span><?php echo $product['isbn13']?></span></span> <br>
            <strong> Format:</strong><span><?php echo $product['format']?></span> <br>
            <strong> Publisher:</strong><span><?php echo $product['publisher']?></span> <br>
                <strong> Edition:</strong><span><?php echo $product['edition']?></span> <br>
            
            </div><br>
            
          
        </div>
        <div class="col-xs-12 col-sm-3 pull-right no-padding">
            <div class="cart-button button-group pull-right" style="width:100%; text-align:left'"> 
            
            <div style="float: left; text-align: left; font-size: 20px;"><strong>Buying Options</strong></div>
            <div class="clear10"></div>
            
            <span style="font-size:14px; float:left; margin-right:10px;"><span style="font-size:18px;font-weight:600;color:rgba(0,0,0,.3);"><?=$total_sellers_for_new?> New </span> from <span style="color:#bb9870;font-size:18px;"><strong>$<?php if($min_new_price[0]['price']) echo round($min_new_price[0]['price'],2); else echo '0'; ?></strong></span> |</span>
            


            <span style="font-size:14px; float:left;"><span style="font-size:18px; font-weight:600;color: rgba(0,0,0,.3);"><?=$total_sellers_for_used?> Used </span> from <span style="color:rgb(187, 152, 112) !important;font-size:18px;"><strong>$<?php if($min_used_price[0]['price']) echo round($min_used_price[0]['price'],2); else echo '0';?></strong></span></span>
            
            
            
             <br>
             <p style="line-height:24px; margin-bottom:10px; clear:both;">
             </p>

             <?php /*?> <p style="line-height:31px; color:#999; display: inline;">Quantity</p>
              <input type="text" class="form-control" maxlength="5" size="3" name="new_qty" id="new_qty_1" value="1" style="width:68px; margin-bottom:16px; float:right;">
              <br><?php */?>
              
              <a class="btn btn-cart pull-right" type="button" href="<?php echo base_url("product/detail");?>/<?php echo encode_url($product['product_id'])?>" title="View Detail" >
                 View Detail  
               </a>
              <br>
            </div>
          </div>
      </div>
                            <?php }
                        } else {
                            echo '<div class="alert alert-danger">Sorry ! No product found</div>';
                        }
						}
                        ?>
                    </div>


                    <!--accordian-->
                    <div class="col-lg-10 col-md-9 col-sm-12 col-xs-12"> <?php echo $pagination; ?></div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="clear35"></div>
<!--<script type='text/javascript' src='http://ajax.googleapis.com/ajax/libs/jquery/1.6/jquery.min.js?ver=3.4.2'></script> -->


<script>
    $(document).ready(function () {
        $("body").on('click', '.filter-toggler', function (e) {
            var ctrl = $(this);
            var parentCtrl = ctrl.parent();
            var filter_block = parentCtrl.find('.filter-block');
            filter_block.toggle();
        });
    });
</script>
<script>
    $(function () {
        $('.button-checkbox').each(function () {

            // Settings
            var $widget = $(this),
                $button = $widget.find('button'),
                $checkbox = $widget.find('input:checkbox'),
                color = $button.data('color'),
                settings = {
                    on: {
                        icon: 'glyphicon glyphicon-check'
                    },
                    off: {
                        icon: 'glyphicon glyphicon-unchecked'
                    }
                };

            // Event Handlers
            $button.on('click', function () {
                $checkbox.prop('checked', !$checkbox.is(':checked'));
                $checkbox.triggerHandler('change');
                updateDisplay();
            });
            $checkbox.on('change', function () {
                updateDisplay();
            });

            // Actions
            function updateDisplay() {
                var isChecked = $checkbox.is(':checked');

                // Set the button's state
                $button.data('state', (isChecked) ? "on" : "off");

                // Set the button's icon
                $button.find('.state-icon')
                    .removeClass()
                    .addClass('state-icon ' + settings[$button.data('state')].icon);

                // Update the button's color
                if (isChecked) {
                    $button
                        .removeClass('btn-default')
                        .addClass('btn-' + color + ' active');
                }
                else {
                    $button
                        .removeClass('btn-' + color + ' active')
                        .addClass('btn-default');
                }
            }

            // Initialization
            function init() {

                updateDisplay();

                // Inject the icon if applicable
                if ($button.find('.state-icon').length == 0) {
                    $button.prepend('<i class="state-icon ' + settings[$button.data('state')].icon + '"></i> ');
                }
            }

            init();
        });
    });


</script>

<script>


    function set_cat(cat) {
        $('#cat_id').val(cat);
        $("#frm_filter").submit();
    }
    function set_color(color) {
        $('#product_color').val(color);
        $("#frm_filter").submit();
    }

    function set_deals(deal) {
        //$('#cat_id').val(cat);

        var $checkbox = $('#' + deal);
        //alert(checkbox);
        $checkbox.attr('checked', !$checkbox[0].checked);
        $("#frm_filter").submit();
    }

    function filter_condition(condition_value) {
        $('#condition').val(condition_value);
        $("#frm_filter").submit();
    }
    function filter_type(type_value) {
        $('#type').val(type_value);
        $("#frm_filter").submit();
    }
</script>
<style>
@media screen and (min-device-width: 320px) and (max-device-width: 767px) { 
.btn-cart
{
	margin-bottom:5px;
}
}

.main-content-cont h1, .main-content-cont h2, .main-content-cont h3, .main-content-cont h4
{
	font-weight:bold !important;
}

</style>