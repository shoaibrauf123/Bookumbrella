<?php 
class Ammar extends CI_Controller
{
    function zahid(){
        echo "hello zahid";
    }
}
?>
